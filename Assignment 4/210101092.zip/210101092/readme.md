**CS242 Assignment 4**

**Question 1**

Command used for execution in linux terminal is : python 210101092_Assign4_Ques1.py

This program is written in python 3.10.2. It is used to implement Coin Problem.


# VARIABLE NAMES

# amount 			-  Stores amount given by user
# coin_values		-  list storing the denominations available
# dict	    		-  Dictionary storing the index and amount in coin_values
# dp               	-  List storing the minimum coins required for all numbers till amount
# values             -  List storing all possible permutations of coin values of given amount
# minimum            -  Minimum of the elements of list values


The program uses dynamic programming to calculate the minimum amount of coins required. For a given amount, all amounts lesser than the previous amounts are stored in a list dp and the list extracts the minimal possible no of coins in an iterative fashion.

**Question 2**

PREREQUISITE INSTALLING NUMPY : If numpy is not installed, type "pip install numpy" in terminal
Command used for execution in linux terminal is : pdflatex page1.tex or pdflatex page2.tex

This program is written in latex and is used to write pdf.



# VARIABLE NAMES IMPORTED FROM MATH

# \gamma 					-  Symbol gamma
# \thetha		    		-  Symbol thetha
# \omega	    		    -  Symbol omega
# \rho             	        -  Symbol rho
# \nabla 					-  Symbol delta
# \epsilon		    		-  Symbol epsilon
# \mu	    		        -  Symbol mu
# \alpha 					-  Symbol alpha
# \beta  		    		-  Symbol beta
# \delta	    		    -  Symbol delta
# \pi               	    -  Symbol pi
# \prime 					-  Symbol '
# \geq		    		    -  Symbol greater than or equal to
# \sum	    		        -  Symbol of summation
# \prod	    		        -  Symbol of multiplication
# \ldots				    -  lateral dots
# \vdots		            -  vertical dots
# \ddots	    		    -  diagonal dots

Here we have used amsmath package to write mathematical equations. Also we assume that the equations are referenced to the equation number. If otherwise the commented code for hyperlinking the pages to wikipedia pages is also available below the actual code.