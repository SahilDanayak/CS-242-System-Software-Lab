#Question 1 COIN PROBLEM

#This program is created to implement coin problem with output as minimum sum of coins required
#CREATED BY
#Sahil Danayak
#210101092

#VARIABLE NAMES

#amount 			-  Stores amount given by user
#coin_values		-  list storing the denominations available
#dict	    		-  Dictionary storing the index and amount in coin_values
#dp               	-  List storing the minimum coins required for all numbers till amount
#values             -  List storing all possible permutations of coin values of given amount
#minimum            -  Minimum of the elements of list values

#Asks user to input the amount of money
amount=int(input("Enter amount : "))

#It is a python list containing the denominations of coins
coin_values=[1,5,10,20,25,50]
#A dictionary is created with amount and index as key value pair

dict={j:i for i,j in enumerate(coin_values)}
#A list which contains minimum no of coins required to have i amount of money at ith index
dp=[]    #dp stands for dynamic programming

#You need no coins to pay at 0 rupees
dp.append([0]*len(coin_values)) #It stores a list with each entry 0

#creating a for loop to fill the entries of dp one by one
for i in range(1,amount+1):
    values=[]
    #If a coin of particular denomination is available, then just use it
    if i in coin_values :
        l=[0]*len(coin_values)
        l[dict[i]]=1
        dp.append(l) #Appends one-hot encoding of the coin as list to dp
        continue
    # for each denomination subtracting it from amount and then checking for minimum number of coins required to have that much amount
    for coin in coin_values :
        if i-coin>=0:
            l=dp[i-coin].copy()
            l[dict[coin]]+=1    #increasing the desired value of denomination by 1
            values.append(l)
    # finding the minimum no of coins required from that denomination added.
    minimum=[99999]*len(coin_values)
    for i in values:
        if sum(i)<sum(minimum):
            minimum=i
    dp.append(minimum)
    # appending that value to dp list

# printing the minimum no of coins required the amount
print("Minimum number of coins required : ",sum(dp[amount]))
print()
for i in range(len(dp[amount])):
    print("No of denomination of",coin_values[i],"rupee : ",dp[amount][i])  #printing no of coins of each denomination