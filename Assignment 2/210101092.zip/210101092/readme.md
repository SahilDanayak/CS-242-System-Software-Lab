**CS242 Assignment 2**

**Question 1**

Command used for execution in linux terminal is : bash 210101092_Assign2_Ques1.scr filename backup

#First command line argument corresponds to the filename i.e. the name of file which stores the list of files.
#Second command line argument corresponds to the backup directory location.

This program is written in bash. It is used to create backup files.
210101092_Assign2_Ques1.scr is the name of the source code of the first file, filename contains list of files while backup is the destination directory. 
All the files (filename,backup,210101092_Assign2_Ques1.scr )are assumed to be in same directory while all data to be copied is assumed to be in home directory.
A function syntax is used to show the correct syntax of creating backup files. The first while loop checks whether the number of arguments provided is 2. Else the code prints if it as an error.The else loop checks whether there is a source filename in the same directory as this backup script by using the function -f ans also checks whether there is a backup directory in the same directory as this backup script by using the function -d. A while loop is used to read all file names from the list of files. The files are copierd using the cp command and their extension are changed using the mv command. If file in list of files is not found, the program terminates, stating the name of file not found.

**Question 2**

Command used for execution in linux terminal is : perl 210101092_Assign2_Ques2.pl 2 100

#First command line argument corresponds to the max repetition count of the string
#Second command line argument corresponds to the length of the string.

This program is written in perl. 
If count is 4 max repetition allowed is 3 i.e (a,aa,aaa,b,bb,bbb) as given in problem statement for characters a and b.
A single string of alphabets is to be provided in the input file "input_alphabets" and its various characters would be used for repetition.
The length of the output string should be equal to the input length given.
The arguments length and count are used from commandline. The program tries to open file with file handle "FILE" and reads its contents. These contents are stored in the array data. A while loop is created which runs till the length of the string is less than input length. In it two random variables repetition and index are choosen suitabely. These values may be changed using a while loop if not found apt. A substring is created using repetiton of the current character and that substring is concatenated to the original string.
