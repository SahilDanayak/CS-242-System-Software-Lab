#!usr/bin/perl

# open file 210101092_Assign2_Ques2.pl

#CREATED BY
#Sahil Danayak
#210101092

#ASSUMPTIONS

#1. If count is 4 max repetition allowed is 3 i.e (a,aa,aaa,b,bb,bbb) as given in problem statement for characters a and b.
#2. A single string of alphabets is to be provided in the input file "input_alphabets" and its various characters would be used for repetition.
#3. The length of the output string should be equal to the input length given.

#COMMAND LINE ARGUMENTS

#First command line argument corresponds to the max repetition count of the string
#Second command line argument corresponds to the length of the string.

#VARIABLES

#filename - name of file
#array data - data stored in file "input_alphabets"
#count - maximum repetiton in string -1
#len - length of output string
#size_of_array = size of array data
#string - the final output string
#index - the index of character in array data to be repeated to form substring (1st random variable)
#previndex - the index of character used in previous substring
#repetition - the number of times the character has to be repeated to form substring (2nd random variable)
#substring - the substring formed by repetition of characters.
#char - character to be repeated


#MAIN PROGRAM

$filename="input_alphabets";	#variable storing input filename
open(FILE, $filename) or die("Unable to open file"); #If first statement is False ,the or statement is executed and the program terminates stating that the file cant be opened.
#Here the file handle is FILE and the file is opened using open command

my @data = split('', <FILE>); #this line splits the data in file into an array, seperating by delimiter '' which partitions it into individual characters
close(FILE);	#The open file is closed and the memory associated with the FILE is cleared.

#This line asks the user to enter max repetition count of the string.
$count=shift; #shift - takes argument as input for count from user
#print "Enter length of string (length): "; #This line asks the user to enter length of the string.
$len=shift; #shift - takes argument as input for count from user
$size_of_array = @data; #referencing a variable just by its name gives its size.
$string = ""; #Now we are initializing the string
$index=0; #Now we are initializing the index to 0






if ($count<=1){print "Count should be greater than 1\n";exit;}
#checking if count is greater than one using a if loop. The program terminates if count is less than or equal to 1.

while (length($string)<$len)						#Creating a while loop which runs till the length of the string is less than input length
{
	$previndex=$index;						#setting the previous index to current index
	while($previndex==$index){$index = int(rand($size_of_array-1));}		#choosing a new index which is different from previous index
	$repetition = 1+int(rand($count-1));					#choosing no of times the character should be repeated
	while($repetition + length($string)>$len){$repetition = 1+int(rand($count-1));}     #If the length of substring and string is greater than length variable, do not concatenate, instead choose a new value of length
	$char=$data[$index];		# initialising variable char to corresponding element of data array
	chomp($char);			#removing subsequent hidden characters from char
	$substring="$char" x $repetition; # Creating a substring by repeating the characters repetition number of times
	$string = $string.$substring;   # Creating a new string by concatenating substring with the previous string
	
	
}
print "String : $string\n";		#Printing output of string


