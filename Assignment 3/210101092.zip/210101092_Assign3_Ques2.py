#Question 2 : 8 puzzle problem

#This program uis created to solve 8 puzzle problem using minimum number of steps in python
#CREATED BY
#Sahil Danayak
#210101092


#ASSUMPTIONS

#1. Numpy library is installed. if not, install it via "pip install numpy" command in terminal.
#2. In each step we have to print the matrix and the direction moved.
#3. Initial and goal configuration should be user decided and inputed in format
#Eg : Input configuration
#        2 3 6
#        1 7 5
#        4 8 0
#4. The missing position is printed as 0


#VARIABLE NAMES

#nodes 					-  Python dictionary storing matrix as key and a list [matrix,parentmatrix,cost,level,direction] as its value
#steps		    		-  Number of Steps taken to solve the problem
#row(i)	    		    -  ith row of matrix as taken input from user
#initial_matrix_string  -  Initial matrix stored as a string
#initial_matrix         -  Initial matrix stored as a 2D numpy array
#goal_matrix_string     -  Goal matrix stored as a string
#goal_matrix            -  Goal matrix stored as a 2D numpy array
#minimum                -  Matrix node having minimum cost + 5*level from all nodes in python dictionary
#index_of_0             -  Index of element 0 in minimum (string form)
#i                      -  ith index of element 0 in minimum (matrix form)
#j                      -  jth index of element 0 in minimum (matrix form)
#level                  -  minimum distance of a matrix from original matrix


#FUNCTIONS USED

#to_matrix(string)      -  takes argument as a string and converts it to 2d matrix
#to_string(matrix)      -  takes argument as a matrix and converts it to string
#compute_cost()         -  takes argument as initial and goal matrix and computes the manhatten cost between them given by the formula |x1-x2|+|y1-y2|
#swap()                 -  takes argument as a matrix and two pairs of coordinates (i1,j1) and (i2,j2) and exchanges them
#printmatrix()          -  takes argument as a matrix and prints it elementwise
#node()                 -  takes matrix, parent matrix,level and direction and computes cost and creates a node in dictionary
#printpath()            -  prints path from given matrix to initial_matrix
#is_solvable()          -  takes initial matrix and final matrix as arguments and checks whether it is solvable or not  


#importing a 0 matrix from numpy
from numpy import zeros

"""
This function converts a string to matrix
 Eg: 123456780 is converted to [[1,2,3],[4,5,6],[7,8,0]]
 """

def to_matrix(string):
    matrix=zeros((3,3),dtype=int)       #initiaizing matrix as a 2D 3 x 3 numpy array
    for i in range(3):
        for j in range(3):
            matrix[i][j]=int(string[3*i+j])   #converting a string to matrix
    return matrix

"""
This function converts a string to matrix
 Eg: 123456780 is converted to [[1,2,3],[4,5,6],[7,8,0]]
 """

def to_string(matrix):
    string=""                       #initializing string
    for i in range(3):
        for j in range(3):
            string+=str(matrix[i][j])   #concatenating each element as a string into the matrix
    return string

"""
This function computes the cost of a matrix based on goal matrix using manhatten distance

for each no in matrix, the absolute sum of distance bw the x and y coordinates is added to cost
"""

def compute_cost(initial_matrix,goal_matrix):
    cost=0      #initializing cost function
    x1=x2=y1=y2=0   #setting variables to 0
    for no in range(1,9):
    	for i in range(3):
    		for j in range(3):
                 if (initial_matrix[i][j]==no):x1,y1=i,j        #finding positions of the number in initial matrix
                 if (goal_matrix[i][j]==no):x2,y2=i,j           #finding positions of the number in final matrix
                 cost+=abs(x2-x1)+abs(y2-y1)                    #adding these values
    return cost

"""
This function takes a matrix and 2 pairs of positions of elements
it swaps the elements in these positions

"""

def swap(initial_matrix,i1,j1,i2,j2):
	initial_matrix[i1][j1],initial_matrix[i2][j2]=initial_matrix[i2][j2],initial_matrix[i1][j1]

"""
This function takes a matrix and prints it on terminal
"""

def printmatrix(matrix):
    for i in range(3):
        for j in range(3):
            print(int(matrix[i][j]),end=" ")    #a keyword argument end is used to prevent each element form prining in new line
        print()
    print()

"""
This function takes matrix , its parent ,its distance from the initial_matrix and direction of the toggling of 0 as arguments.
It computes the cost of the matrix using the above function and then stores it in a dictionary whose key is the string equivalent of the given matrix

Eg 134526087 : [    [1,3,4]        , 134026587      ,   18      ,   3       , "DOWN"        ]
                    [5,2,6]
                    [0,8,7]

"""

def node(matrix,parent_matrix_string,level,dir):
    matrix_string=to_string(matrix)     #converting the given matrix into string form
    if (matrix_string not in nodes.keys()): #if it is already present, do not add it
        cost=compute_cost(matrix,goal_matrix)       #computing the cost of the matrix
        nodes[matrix_string]=[matrix,parent_matrix_string,cost,level,dir]       #adding the node to dictionary

"""
This function prints the path of from initial matrix to the matrix given as argument by repeatedly calling printmatrix() function
"""


def printpath(matrix_string):
    global steps        #steps is assigned as a global variable here
    if nodes[matrix_string][1]==matrix_string:return        #checking if initial matrix is reached, then terminate
    printpath(nodes[matrix_string][1])                      #else printing the path and incrementing step by 1
    steps+=1
    print("----- STEP",steps,nodes[matrix_string][4],"-----")
    printmatrix(nodes[matrix_string][0])
    #print(steps)

"""
This function checks if the goal state is attainable or not.
For this it uses the concept of inversion counts. If it has even number of inversion counts,it returns True else False
"""

def issolvable(initial_matrix_string,goal_matrix_string):
    inv=0
    for i in range(1,9):
        for j in range(i+1,9):
            # This checks if the no pair which is first in string occurs first in goal as well
            if (initial_matrix_string.index(str(i))-initial_matrix_string.index(str(j)))*(goal_matrix_string.index(str(i))-goal_matrix_string.index(str(j)))<0:
                inv+=1
    return inv%2==0

#   MAIN PROGRAM

#initialising nodes to be an empty dictionary and steps to be 0

nodes={}
steps=0

#Asking for input from user for initial matrix

print("Enter initial state matrix")

row1=input().replace(" ","")
row2=input().replace(" ","")
row3=input().replace(" ","")
initial_matrix_string=row1+row2+row3        #concatenating the rows after removing the spaces to produce matrix string
initial_matrix=to_matrix(initial_matrix_string) #converting matrix string to a 2D matrix

#Asking for input from user for initial matrix

print("Enter goal state of matrix")

row1=input().replace(" ","")
row2=input().replace(" ","")
row3=input().replace(" ","")
goal_matrix_string=row1+row2+row3   #concatenating the rows after removing the spaces to produce matrix string
goal_matrix=to_matrix(goal_matrix_string)   #converting matrix string to a 2D matrix


#Adding the initial matrix to the dictionary of nodes and setting its parent to itself
node(initial_matrix,initial_matrix_string,0,"START")

#Checking whether the configuration is solvable
if not issolvable(initial_matrix_string,goal_matrix_string):
    print("Not solvable")
else:
    while True:     #creating an infinite loop which terminates till final configuration is reached
        minimum=list(nodes.keys())[0]   #initializing minimum
        for key in list(nodes.keys()):
            #checking for minimum node on the basis of cost+5*level to give optimum results
            if nodes[key][2]+5*nodes[key][3]<nodes[minimum][2]+5*nodes[minimum][3]:
                minimum=key

        if nodes[minimum][2]==0:        #if final matrix is found
            print("\n-----  START  -----")
            printmatrix(initial_matrix) #printing initial matrix
            printpath(minimum)  #printing path from initial matrix to result
            break

        index_of_0=minimum.index('0')   #finding index of 0 in matrix string
        i=index_of_0//3                 #converting the index into i,j format for 2d matrix
        j=index_of_0%3
        matrix=nodes[minimum][0].copy() #copying the matrix into a new variable
        level=nodes[minimum][3]         #copying the level of the node into a variable level


        if 0<i: #if we can go up
            swap(matrix,i,j,i-1,j)      #shifting 0 up
            node(matrix.copy(),minimum,level+1,"UP")    #storing the new matrix node in dictionary
            swap(matrix,i-1,j,i,j)
        if i<2: #if we can go down
            swap(matrix,i,j,i+1,j)
            node(matrix.copy(),minimum,level+1,"DOWN")  #storing the new matrix node in dictionary
            swap(matrix,i+1,j,i,j)
        if 0<j: #if we can go left
            swap(matrix,i,j,i,j-1)
            node(matrix.copy(),minimum,level+1,"LEFT")  #storing the new matrix node in dictionary
            swap(matrix,i,j-1,i,j)
        if j<2: #if we can go right
            swap(matrix,i,j,i,j+1)
            node(matrix.copy(),minimum,level+1,"RIGHT") #storing the new matrix node in dictionary
            swap(matrix,i,j+1,i,j)

        nodes[minimum][2]=9999      #making the cost of that node infinity so that the program doesnt loop back to this matrix

    #loop ends here
    print("Total ",steps,"steps")   #printing total number of steps


"""

CODE VALIDITY

This code takes a linear combination of cost and level i.e. cost +5*level to achive a balance between minimizing
execution time and no of steps taken. it iterates over the dictionary and finds minimum such node. after finding a node,
it toggles in all possible possible directions and adds the matrices as nodes to a dictionary. At the end, it sets cost=9999
to increase the expence of visiting the same node again. Thus by heuristics, the program is bound to terminate if it is
solvable.

"""