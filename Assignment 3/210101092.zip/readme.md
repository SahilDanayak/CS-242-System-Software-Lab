**CS242 Assignment 3**

**Question 1**

Command used for execution in linux terminal is : python 210101092_Assign3_Ques1.py

This program is written in python 3.9.2. It is used to implement Joseph Problem.


# VARIABLE NAMES

# n 				-  Number of persons standing in a circle facing the centre
# k		    		-  Skip number
# lst	    		-  The list containing the people surviving in each iteration
# starting_index  	-  The index of the starting person in the list

n is the number of people and k is skip number. The loop iterates in a while loop and kills a person in each execution till there is only one person left. If the loop variable is more than terminal value, it subtracts the length of loop from it. The execution order is stored in a list and the person killed is removed from the original list.

**Question 2**

PREREQUISITE INSTALLING NUMPY : If numpy is not installed, type "pip install numpy" in terminal
Command used for execution in linux terminal is : python 210101092_Assign3_Ques2.py

This program is written in python 3.9.2. It is used to implement 8 Puzzle Problem.

# ASSUMPTIONS

# 1. Numpy library is installed. if not, install it via "pip install numpy" command in terminal.
# 2. In each step we have to print the matrix and the direction moved.
# 3. Initial and goal configuration should be user decided and inputed in format
# Eg : Input configuration
#        2 3 6
#        1 7 5
#        4 8 0
# 4. The missing position is printed as 0


# VARIABLE NAMES

# nodes 				- Python dictionary storing matrix as key and a list [matrix,parentmatrix,cost,level,direction] as its value
# steps		    		 - Number of Steps taken to solve the problem
# row(i)	    		 - ith row of matrix as taken input from user
# initial_matrix_string  - Initial matrix stored as a string
# initial_matrix         - Initial matrix stored as a 2D numpy array
# goal_matrix_string     - Goal matrix stored as a string
# goal_matrix            - Goal matrix stored as a 2D numpy array
# minimum                - Matrix node having minimum cost + 5*level from all nodes in python dictionary
# index_of_0             - Index of element 0 in minimum (string form)
# i                      - ith index of element 0 in minimum (matrix form)
# j                      - jth index of element 0 in minimum (matrix form)
# level                  - minimum distance of a matrix from original matrix

# FUNCTIONS USED

# to_matrix(string)      
It takes argument as a string and converts it to 2d matrix
This function converts a string to matrix
 Eg: 123456780 is converted to [[1,2,3],[4,5,6],[7,8,0]]

# to_string(matrix)      
It  takes argument as a matrix and converts it to string
This function converts a string to matrix
 Eg: 123456780 is converted to [[1,2,3],[4,5,6],[7,8,0]]

# compute_cost()         
It  takes argument as initial and goal matrix and computes the manhatten cost between them given by the formula |x1-x2|+|y1-y2|
This function computes the cost of a matrix based on goal matrix using manhatten distance
for each no in matrix, the absolute sum of distance bw the x and y coordinates is added to cost

# swap()                 
It  takes argument as a matrix and two pairs of coordinates (i1,j1) and (i2,j2) and exchanges them

# printmatrix()          
It  takes argument as a matrix and prints it elementwise
# node()                 
It  takes matrix, parent matrix,level and direction and computes cost and creates a node in dictionary
This function takes matrix , its parent ,its distance from the initial_matrix and direction of the toggling of 0 as arguments.
It computes the cost of the matrix using the above function and then stores it in a dictionary whose key is the string equivalent of the given matrix

Eg 134526087 : [    [1,3,4]        , 134026587      ,   18      ,   3       , "DOWN"        ]
                    [5,2,6]
                    [0,8,7]


# printpath()            
It  prints path from given matrix to initial_matrix
# is_solvable()          
It  takes initial matrix and final matrix as arguments and checks whether it is solvable or not  
For this it uses the concept of inversion counts. If it has even number of inversion counts,it returns True else False

# MAIN CODE
It uses a dictionary to store the nodes and then chooses the minimum element (minimum manhatten cost + 5*level) and toggles 0 in all possible ways in that matrix. This process is repeated till the final output is reached. Since cost is minimized along the flow of path, we must reach a state where cost = 0 which is the intended solution. Then it uses a recursive program to print all the matrices required to reach that path. At the end, it sets cost=9999
to increase the expence of visiting the same node again. Thus by heuristics, the program is bound to terminate if it is
solvable.
