#Question 1 JOSEPHUS PROBLEM

#This program is created to implement josephus problem using list in python
#CREATED BY
#Sahil Danayak
#210101092

#VARIABLE NAMES

#n 					-  Number of persons standing in a circle facing the centre
#k		    		-  Skip number
#lst	    		-  The list containing the people surviving in each iteration
#starting_index  	-  The index of the starting person in the list


#The print statement asks the user to enter the value of no of people
print("Enter the value of n : ",end="")
#This statement takes input from user and stores it in integer form
n=int(input())
#The print statement asks the user to enter the skip number
print("Enter the value of k : ",end="")
#This statement takes input from user and stores it in integer form
k=int(input())
#This statement checks if k<0 else it terminates the loop
if k<0:
	print("Invalid input")
	exit()
#This statement generates a list containing alphabets A,B,C...
lst=[chr(i) for i in range(65,65+n,1)]
#Initialising execution order by an empty list
executionorder=[]
#We assign person A to start the process
starting_index=0
#A while loop is created till only 1 person survives

while (len(lst)!=1):
	#Checking if starting index is more than length of list then iterate back to the starting position of list
	while (starting_index>=len(lst)):
		starting_index-=len(lst)

	#The person to be killed is k more than the starting index
	index_to_be_executed=starting_index+k
	#Checking if starting index is more than length of list then iterate back to the starting position of list
	while (index_to_be_executed>=len(lst)):
		index_to_be_executed-=len(lst)

	#Adding person to be executed in execution list
	executionorder.append(lst[index_to_be_executed])
	#Printing person who gets killed	
	print("Person",lst[starting_index],"kills",lst[index_to_be_executed])
	#Removing that index from list
	lst.pop(index_to_be_executed)
	#Changing the starting index to the next person
	starting_index=index_to_be_executed

#Printing remaining person
print("Person",lst[0],"remains")
print("\nExecution  Order : "," ".join(executionorder),end="\n")
