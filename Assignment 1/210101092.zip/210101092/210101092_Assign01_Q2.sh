#!/bin/bash
#Sahil Danayak
#210101092
#Should be used in linux terminal


#Input file
input="EMPLOYEE"

#Printing headers
printf "Employee Number\\tDepartment\\tPay rate\\tExempt\\tHours worked\\tBase pay\\tOvertime pay\\tTotal  pay\\n"

#reading columns
while read -r empno dept payrate exempt hrs 
# empno - employee number
# dept - department
#payrate - payrate
#exempt - exempt
#hrs - hours

do
	#checks whether exempt is none and wok hours is more than 40
  if [[ "$exempt" = "N" ]] && [[ "$hrs" -gt 40 ]]; then 
	#printing first 5 columns
  	printf "$empno\\t\\t$dept\\t\\t$payrate\\t\\t$exempt\\t$hrs\\t\\t"
	#printing base pay
	#using best calculator to calculate base pay with an accuracy of 2 decimal places
	basepay=$(echo "scale=2;$payrate*$hrs" | bc)
	printf "$basepay\\t\\t"
	#Finding overtime pay
	#using best calculator to calculate overtime with an accuracy of 2 decimal places
	overtime=$(echo "scale=2;$payrate*($hrs-40)/2" | bc)
	printf "$overtime\\t\\t"
	#printing total pay
	total=$(echo "scale=2;$basepay+$overtime" | bc)
	printf "$total\\n"
  else
	#printing first 5 columns
  	printf "$empno\\t\\t$dept\\t\\t$payrate\\t\\t$exempt\\t$hrs\\t\\t"
  	#using best calculator to calculate base pay with an accuracy of 2 decimal places
	basepay=$(echo "scale=2;$payrate*$hrs" | bc)
	#printing remaining columns
	printf "$basepay\\t\\t0\\t\\t$basepay\\n"
  fi
#The for loop completes here  
done < "$input"
#After the program is complete, the offset returns to inpuyt

