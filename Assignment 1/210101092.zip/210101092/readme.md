**CS242 Assignment 1**

**Question 1**

Command used for execution in linux terminal is : awk -f 210101092_Assign01_Q1 INVENTORY

This program is written in awk. 
210101092_Assign01_Q1 is the name of the source code of the first file and INVENTORY is the input file. 
Begin statement indicated the beginning of the code and the print statement prints the headers of various columns of the table. The next if else condition prints 0 if reorder Point is more than Quantity on hand else it prints sum of Quantity on hand and reorder point less minimum order .The tab syntax \t is used to align the columns. The report is ended by end command printing End Report.

**Question 2**

Command used for execution in linux terminal is : bash 210101092_Assign01_Q2.sh

This program is written in bash. 
A file named employeee is used as input file. 
The printf command is used to print all headers of the file. A while loop is used to print the first 5 columns and then calculating the base pay and overtime depeding whether the employee is exempt or not and hours worked. Here we have used best calculator with an accuracy of 2 decimal places to perform float calculation as bash doesnt support decimals. 
For non exempt employees working overtime, we calculate base pay as payrate times the total hours worked while for overtime as payrate*extra hours worked /2. The total pay is calculated as the sum of base pay and overtime pay. After the while loop is completed , we ask the user for input.

